@extends('layout')
@section('content')
	<x-form tipoform='login'/>
@endsection