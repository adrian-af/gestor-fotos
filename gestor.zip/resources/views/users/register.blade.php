@extends('layout')
@section('content')
	<x-form tipoform='registro'/>
@endsection