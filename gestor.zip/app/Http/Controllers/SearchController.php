<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class SearchController extends Controller
{
    public function search(Request $request)
    {
        //$var = $request->search ."<br>";
       /*  $busqueda = $_POST['busqueda'];
        $order = $_POST['order'];
        $desde = $_POST['desde'];
        $hasta = $_POST['hasta']; */
        //return $var;
        return "hola";
    }

}

